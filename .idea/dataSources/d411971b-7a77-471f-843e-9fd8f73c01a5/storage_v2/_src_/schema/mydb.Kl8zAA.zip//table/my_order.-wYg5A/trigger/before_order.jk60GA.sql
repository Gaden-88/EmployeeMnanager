create definer = root@localhost trigger before_order
  before INSERT
  on my_order
  for each row
BEGIN
	SELECT inv FROM my_goods WHERE id = new.g_id INTO @inv;
	IF @inv<new.g_number THEN 
	insert into xxx value(xxx);
	END IF;


END;

