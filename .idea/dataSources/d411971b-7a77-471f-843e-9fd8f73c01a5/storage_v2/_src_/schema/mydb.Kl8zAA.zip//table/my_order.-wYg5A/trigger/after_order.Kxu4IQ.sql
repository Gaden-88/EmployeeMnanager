create definer = root@localhost trigger after_order
  after INSERT
  on my_order
  for each row
begin

update my_goods set inv = inv - new.g_number where id = new.g_id;

end;

